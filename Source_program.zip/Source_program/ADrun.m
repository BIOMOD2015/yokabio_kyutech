clear;

x = 50 * 10^(-9);

IN(1)=2 * x; % input
IN(2)=2 * x; % trigger A
IN(3)=0;
IN(4)=0;
IN(5)=0.6 * x; %transduser A
IN(6)=0;
IN(7)=0; %outputA
IN(8)=2 * x; %gate A
IN(9)=0; 
IN(10)=0;
IN(11)=4 * x; %Fuel A
IN(12)=0;
IN(13)=0;
IN(14)=0;
IN(15)=0;
IN(16)=0;
IN(17)=0;
IN(18)=0;
IN(19)=0;
IN(20)=0;
IN(21)=0.5 * x; %transduser B
IN(22)=0;
IN(23)=0; %outputB
IN(24)=2 * x; %gate B 
IN(25)=0;
IN(26)=0;
IN(27)=4 * x; %Fuel B 
IN(28)=0;
IN(29)=0;
IN(30)=0;
IN(31)=0;
IN(32)=0;
IN(33)=0;
IN(34)=0;
IN(35)=0;
IN(36)=0;
IN(37)=0.4 * x; %transduser C
IN(38)=0;
IN(39)=0; %outputC
IN(40)=2 * x; %gate C
IN(41)=0;
IN(42)=0;
IN(43)=4 * x; %Fuel C 
IN(44)=0;
IN(45)=0;
IN(46)=0;
IN(47)=0;
IN(48)=0;
IN(49)=0;
IN(50)=0;
IN(51)=0;
IN(52)=0;
IN(53)=0.3 * x; %transduser D
IN(54)=0;
IN(55)=0; %outputD
IN(56)=2 * x; %gate D
IN(57)=0;
IN(58)=0;
IN(59)=4 * x; %Fuel D 
IN(60)=0;
IN(61)=0;
IN(62)=0;
IN(63)=0;
IN(64)=0;
IN(65)=0;
IN(66)=0;
IN(67)=0;
IN(68)=0;
IN(69)=0.2 * x; %transduser E
IN(70)=0;
IN(71)=0;  %outputE
IN(72)=2 * x; %gate E
IN(73)=0; 
IN(74)=0;
IN(75)=4 * x; %Fuel E
IN(76)=0;
IN(77)=0; 
IN(78)=0;
IN(79)=0;
IN(80)=0;
IN(81)=0;
IN(82)=0;
IN(83)=0;
IN(84)=0;
IN(85)=0.1 * x; %transduser F
IN(86)=0;
IN(87)=0; %output F
IN(88)=2 * x; %gate F
IN(89)=0;
IN(90)=0;
IN(91)=4 * x; %Fuel F
IN(92)=0;
IN(93)=0;
IN(94)=0;
IN(95)=0;
IN(96)=0;
IN(97)=0;
IN(98)=0;
IN(99)=0;
IN(100)=0;
IN(101)=0.05 * x; %transduser G
IN(102)=0;
IN(103)=0; %output G
IN(104)=2 * x; %gate G
IN(105)=0;
IN(106)=0;
IN(107)=4 * x; %Fuel G 
IN(108)=0;
IN(109)=0;
IN(110)=0;
IN(111)=0;
IN(112)=0;
IN(113)=0;
IN(114)=0;

%in1
IN(115)= 0.7 * x;

%ThresholdgateA-1
IN(116) = 0;       
IN(117) = 2 * x; %fuel
IN(118) = 0;       
IN(119) = 1 * x; %gate:output
IN(120) = 0;       
IN(121) =0.05 * x; %threshould = Vin

%NOTgate-1
IN(122) = 0.8 * x; %Inverter
IN(123) = 1 * x; %gate:output
IN(124) = 0;
IN(125) = 0 * x;
IN(126) = 0.7 * x; %Threshold_Inverter
IN(127) = 0 * x;
IN(128) = 2 * x; %fuel

%ThresholdgateB-1
IN(129) = 0;       
IN(130) = 2 * x; %fuel
IN(131) = 0;       
IN(132) = 1 * x; %gate:output
IN(133) = 0;       
IN(134) =0.3* x; %threshould


%ThresholdgateA-2
IN(135) = 0;       
IN(136) = 2 * x; %fuel 
IN(137) = 0;       
IN(138) = 1 * x; %gate:output
IN(139) = 0;       
IN(140) =0.05 * x; %threshould

%NOTgate-2
IN(141) = 0.8 * x; %Inverter
IN(142) = 1 * x; %gate:output
IN(143) = 0;
IN(144) = 0 * x;
IN(145) = 0.7 * x; %Threshold_Inverter
IN(146) = 0 * x;
IN(147) = 2 * x; %fuel

%ThresholdgateB-2
IN(148) = 0;       
IN(149) = 2 * x; %fuel
IN(150) = 0;     
IN(151) = 1 * x; %gate:output
IN(152) = 0;      
IN(153) =0.3* x; %threshould


%ThresholdgateA-3
IN(154) = 0;       
IN(155) = 2 * x; %fuel
IN(156) = 0;      
IN(157) = 1 * x; %gate:output
IN(158) = 0;       
IN(159) =0.05 * x; %threshould = Vin

%NOTgate-3
IN(160) = 0.8 * x; %Inverter
IN(161) = 1 * x; %gate:output
IN(162) = 0;
IN(163) = 0 * x;
IN(164) = 0.7 * x; %Threshold_Inverter
IN(165) = 0 * x;
IN(166) = 2 * x; %fuel

%ThresholdgateB-3
IN(167) = 0;       
IN(168) = 2 * x; %fuel
IN(169) = 0;       
IN(170) = 1 * x; %gate:output
IN(171) = 0;       
IN(172) =0.3* x; %threshould


%ThresholdgateA-4
IN(173) = 0;       
IN(174) = 2 * x; %fuel 
IN(175) = 0;       
IN(176) = 1 * x; %gate:output
IN(177) = 0;       
IN(178) =0.65 * x; %threshould = Vin

%NOTgate-4
IN(179) = 0.8 * x; %Inverter
IN(180) = 1 * x; %gate:output
IN(181) = 0;
IN(182) = 0 * x;
IN(183) = 0.7 * x; %Threshold_Inverter
IN(184) = 0 * x;
IN(185) = 2 * x; %fuel

%ThresholdgateB-4
IN(186) = 0;      
IN(187) = 2 * x; %fuel 
IN(188) = 0;      
IN(189) = 1 * x; %gate:output
IN(190) = 0;       
IN(191) =0.3* x; %threshould


%ThresholdgateA-5
IN(192) = 0;       
IN(193) = 2 * x; %fuel 
IN(194) = 0;       
IN(195) = 1 * x; %gate:output
IN(196) = 0;       
IN(197) =0.65 * x; %threshould = Vin

%NOTgate-5
IN(198) = 0.8 * x; %Inverter
IN(199) = 1 * x; %gate:output
IN(200) = 0;
IN(201) = 0 * x;
IN(202) = 0.7 * x; %Threshold_Inverter
IN(203) = 0 * x;
IN(204) = 2 * x; %fuel

%ThresholdgateB-5
IN(205) = 0;       
IN(206) = 2 * x; %fuel 
IN(207) = 0;       
IN(208) = 1 * x; %gate:output
IN(209) = 0;       
IN(210) =0.3* x; %threshould


%ThresholdgateA-6
IN(211) = 0;       
IN(212) = 2 * x; %fuel 
IN(213) = 0;       
IN(214) = 1 * x; %gate:output
IN(215) = 0;       
IN(216) =0.65 * x; %threshould = Vin

%NOTgate-6
IN(217) = 0.8 * x; %Inverter
IN(218) = 1 * x; %gate:output
IN(219) = 0;
IN(220) = 0 * x;
IN(221) = 0.7 * x; %Threshold_Inverter
IN(222) = 0 * x;
IN(223) = 2 * x; %fuel

%ThresholdgateB-6
IN(224) = 0;      
IN(225) = 2 * x; %fuel
IN(226) = 0;       
IN(227) = 1 * x; %gate:output
IN(228) = 0;       
IN(229) =0.3* x; %threshould


%ThresholdgateA-7
IN(230) = 0;      
IN(231) = 2 * x; %fuel 
IN(232) = 0;     
IN(233) = 1 * x; %gate:output
IN(234) = 0;       
IN(235) =0.65 * x; %threshould = Vin

%NOTgate-7
IN(236) = 0.8 * x; %Inverter
IN(237) = 1 * x; %gate:output
IN(238) = 0;
IN(239) = 0 * x;
IN(240) = 0.7 * x; %Threshold_Inverter
IN(241) = 0 * x;
IN(242) = 2 * x; %fuel

%ThresholdgateB-7
IN(243) = 0;      
IN(244) = 2 * x; %fuel 
IN(245) = 0;       
IN(246) = 1 * x; %gate:output
IN(247) = 0;      
IN(248) =0.3* x; %threshould


%ThresholdgateA-8
IN(249) = 0;       
IN(250) = 2 * x; %fuel 
IN(251) = 0;     
IN(252) = 1 * x; %gate:output
IN(253) = 0;      
IN(254) =0.65 * x; %threshould = Vin

%NOTgate-8
IN(255) = 0.8 * x; %Inverter
IN(256) = 1 * x; %gate:output
IN(257) = 0;
IN(258) = 0 * x;
IN(259) = 0.7 * x; %Threshold_Inverter
IN(260) = 0 * x;
IN(261) = 2 * x; %fuel


%ANDgate-1
IN(262) = 0 * x;  
IN(263) = 0 * x;
IN(264) = 0 * x;    
IN(265) = 2 * x; %g1_gate:output
IN(266) = 0 * x;     
IN(267) = 0.6 * x; %g1_threshould_input1
IN(268) = 0.75 * x; %g4_threshould 
IN(269) = 0.6 * x; %g1_threshould_inout2

IN(270) = 0 * x;
IN(271) = 2 * x; %g2_fuel
IN(272) = 0 * x;    
IN(273) = 2.5 * x; %g2_gate:output
IN(274) = 0 * x;   
IN(275) = 0.6 * x; %g2_threshould
IN(276) = 0.6 * x; %g3_threshould

IN(277) = 0 * x; 
IN(278) = 2.5 * x; %g3_gate:input
IN(279) = 0 * x;    
IN(280) = 0.5 * x; %g3_gate:waste

IN(281) = 0 * x;   
IN(282) = 2 * x; %g4_fuel
IN(283) = 0 * x;    
IN(284) = 1 * x; %g4_gate:output
IN(285) = 0 * x;   


% ANDgate2
IN(286) = 0 * x;
IN(287) = 0 * x;
IN(288) = 0 * x;    
IN(289) = 2 * x; %g1_gate:output
IN(290) = 0 * x;   
IN(291) = 0.6 * x; %g1_threshould_input1
IN(292) = 0.75 * x; %g4_threshould
IN(293) = 0.6 * x; %g1_threshould_inout2

IN(294) = 0 * x;
IN(295) = 2 * x; %g2_fuel
IN(296) = 0 * x;   
IN(297) = 2.5 * x; %g2_gate:output
IN(298) = 0 * x;    
IN(299) = 0.6 * x; %g2_threshould
IN(300) = 0.6 * x; %g3_threshould

IN(301) = 0 * x; 
IN(302) = 2.5 * x; %g3_gate:input
IN(303) = 0 * x;    
IN(304) = 0.5 * x; %g3_gate:waste

IN(305) = 0 * x;    
IN(306) = 2 * x; %g4_fuel
IN(307) = 0 * x;    
IN(308) = 1 * x; %g4_gate:output
IN(309) = 0 * x;    


%ANDgate3
IN(310) = 0 * x;  
IN(311) = 0 * x;
IN(312) = 0 * x;    
IN(313) = 2 * x; %g1_gate:output
IN(314) = 0 * x;     
IN(315) = 0.6 * x; %g1_threshould_input1
IN(316) = 0.75 * x; %g4_threshould
IN(317) = 0.6 * x; %g1_threshould_inout2

IN(318) = 0 * x;
IN(319) = 2 * x; %g2_fuel
IN(320) = 0 * x;    
IN(321) = 2.5 * x; %g2_gate:output
IN(322) = 0 * x;   
IN(323) = 0.6 * x; %g2_threshould
IN(324) = 0.6 * x; %g3_threshould

IN(325) = 0 * x; 
IN(326) = 2.5 * x; %g3_gate:input
IN(327) = 0 * x;    
IN(328) = 0.5 * x; %g3_gate:waste

IN(329) = 0 * x;    
IN(330) = 2 * x; %g4_fuel
IN(331) = 0 * x;    
IN(332) = 1 * x; %g4_gate:output
IN(333) = 0 * x;   


% ANDgate4
IN(334) = 0 * x;
IN(335) = 0 * x;
IN(336) = 0 * x;    
IN(337) = 2 * x; %g1_gate:output
IN(338) = 0 * x;    
IN(339) = 0.6 * x; %g1_threshould_input1
IN(340) = 0.75 * x; %g4_threshould
IN(341) = 0.6 * x; %g1_threshould_inout2

IN(342) = 0 * x;
IN(343) = 2 * x; %g2_fuel
IN(344) = 0 * x;    
IN(345) = 2.5 * x; %g2_gate:output
IN(346) = 0 * x;    
IN(347) = 0.6 * x; %g2_threshould
IN(348) = 0.6 * x; %g3_threshould

IN(349) = 0 * x; 
IN(350) = 2.5 * x; %g3_gate:input
IN(351) = 0 * x;    
IN(352) = 0.5 * x; %g3_gate:waste

IN(353) = 0 * x;    
IN(354) = 2 * x; %g4_fuel
IN(355) = 0 * x;   
IN(356) = 1 * x; %g4_gate:output
IN(357) = 0 * x;   


%ANDgate5
IN(358) = 0 * x;  
IN(359) = 0 * x;
IN(360) = 0 * x;    
IN(361) = 2 * x; %g1_gate:output
IN(362) = 0 * x;     
IN(363) = 0.6 * x; %g1_threshould_input1
IN(364) = 0.75 * x; %g4_threshould
IN(365) = 0.6 * x; %g1_threshould_inout2

IN(366) = 0 * x;
IN(367) = 2 * x; %g2_fuel
IN(368) = 0 * x;    
IN(369) = 2.5 * x; %g2_gate:output
IN(370) = 0 * x;    
IN(371) = 0.6 * x; %g2_threshould
IN(372) = 0.6 * x; %g3_threshould

IN(373) = 0 * x; 
IN(374) = 2.5 * x; %g3_gate:input
IN(375) = 0 * x;    
IN(376) = 0.5 * x; %g3_gate:waste

IN(377) = 0 * x;    
IN(378) = 2 * x; %g4_fuel
IN(379) = 0 * x;    
IN(380) = 1 * x; %g4_gate:output
IN(381) = 0 * x;   


% ANDgate6
IN(382) = 0 * x;
IN(383) = 0 * x;
IN(384) = 0 * x;    
IN(385) = 2 * x; %g1_gate:output
IN(386) = 0 * x;   
IN(387) = 0.6 * x; %g1_threshould_input1
IN(388) = 0.75 * x; %g4_threshould
IN(389) = 0.6 * x; %g1_threshould_inout2

IN(390) = 0 * x;
IN(391) = 2 * x; %g2_fuel
IN(392) = 0 * x;    
IN(393) = 2.5 * x; %g2_gate:output
IN(394) = 0 * x;    
IN(395) = 0.6 * x; %g2_threshould
IN(396) = 0.6 * x; %g3_threshould

IN(397) = 0 * x; 
IN(398) = 2.5 * x; %g3_gate:input
IN(399) = 0 * x;    
IN(400) = 0.5 * x; %g3_gate:waste

IN(401) = 0 * x;    
IN(402) = 2 * x; %g4_fuel
IN(403) = 0 * x;   
IN(404) = 1 * x; %g4_gate:output
IN(405) = 0 * x;   


%ANDgate7
IN(406) = 0 * x;  
IN(407) = 0 * x;
IN(408) = 0 * x;    
IN(409) = 2 * x; %g1_gate:output
IN(410) = 0 * x;    
IN(411) = 0.6 * x; %g1_threshould_input1
IN(412) = 0.75 * x; %g4_threshould
IN(413) = 0.6 * x; %g1_threshould_inout2

IN(414) = 0 * x;
IN(415) = 2 * x; %g2_fuel
IN(416) = 0 * x;   
IN(417) = 2.5 * x; %g2_gate:output
IN(418) = 0 * x;   
IN(419) = 0.6 * x; %g2_threshould
IN(420) = 0.6 * x; %g3_threshould

IN(421) = 0 * x; 
IN(422) = 2.5 * x; %g3_gate:input
IN(423) = 0 * x;   
IN(424) = 0.5 * x; %g3_gate:waste

IN(425) = 0 * x;    
IN(426) = 2 * x; %g4_fuel
IN(427) = 0 * x;   
IN(428) = 1 * x; %g4_gate:output
IN(429) = 0 * x;    


% ANDgate8
IN(430) = 0 * x;
IN(431) = 0 * x;
IN(432) = 0 * x;    
IN(433) = 2 * x; %g1_gate:output
IN(434) = 0 * x;   
IN(435) = 0.6 * x; %g1_threshould_input1
IN(436) = 0.75 * x; %g4_threshould
IN(437) = 0.6 * x; %g1_threshould_inout2

IN(438) = 0 * x;
IN(439) = 2 * x; %g2_fuel
IN(440) = 0 * x;   
IN(441) = 2.5 * x; %g2_gate:output
IN(442) = 0 * x;    
IN(443) = 0.6 * x; %g2_threshould
IN(444) = 0.6 * x; %g3_threshould

IN(445) = 0 * x; 
IN(446) = 2.5 * x; %g3_gate:input
IN(447) = 0 * x;    
IN(448) = 0.5 * x; %g3_gate:waste

IN(449) = 0 * x;    
IN(450) = 2 * x; %g4_fuel
IN(451) = 0 * x;    
IN(452) = 1 * x; %g4_gate:output
IN(453) = 0 * x;    

%ORgate
IN(454) = 0; %output = X2
IN(455) = 0; %output = X1
IN(456) = 0; %output = X0
IN(457) = 6 * x; %fuel
IN(458) = 0; %gate:input7
IN(459) = 0; %gate:input6
IN(460) = 0; %gate:input5
IN(461) = 0; %gate:input4
IN(462) = 0; %gate:input3
IN(463) = 0; %gate:input2
IN(464) = 0; %gate:input1
IN(465) = 1 * x; %gate:output2
IN(466) = 1 * x; %gate:output1
IN(467) = 1 * x; %gate:output0
IN(468) = 0; %gate:fuel
IN(469) = 0.5 * x; %threshould7 = Vin
IN(470) = 0.5 * x; %threshould6 = Vin
IN(471) = 0.5 * x; %threshould5 = Vin
IN(472) = 0.5 * x; %threshould4 = Vin
IN(473) = 0.5 * x; %threshould3 = Vin
IN(474) = 0.5 * x; %threshould2 = Vin
IN(475) = 0.5 * x; %threshould1 = Vin

%in2
IN(476) = 0.01 * x; 



options = odeset('RelTol',2e-10,'AbsTol',1e-12);
[t,y] = ode15s('ADmodel',[0 700000],IN,options);


figure(6)
plot(t,y(:,454)/x,'b','LineWidth',3);
legend('X2');
axis([0,700000,0,1]);

figure(7)
plot(t,y(:,455)/x,'r','LineWidth',3);
legend('X1');
axis([0,700000,0,1]);

figure(8)
plot(t,y(:,456)/x,'g','LineWidth',3);
legend('X0');
axis([0,700000,0,1]);
