function f =ADmodel(t,IN)
f = zeros(476,1);


km = 1 * 10 ^ 7;
kf = 2 * 10 ^ 6;
ks = 1 * 10 ^ 5;
krf=10;


in1 = IN(1);
tri1 = IN(2);
in1_tri1 = IN(3); %input-trigger-complex1
sig1 = IN(4); %signal1
trans1 = IN(5); %transduser1
sig1_trans1 = IN(6); %signal-transduser-complex1
out1 = IN(7); %output1
gate1 = IN(8); %gate1
n_tri1 = IN(9); %newtrigger1
sig1_gate1 = IN(10); %signal-gate-complex1
fuel1 = IN(11); %fuel1
w_1_1 = IN(12); %fuel-(signal-gate-complex)complex1
w_1_2 = IN(13); %gate-newtrigger-complex1
w_1_3 = IN(14); %fuel*2-(signal-gate-complex)complex1
w_1_4 = IN(15); %newtrigger-fuel-(signal-gate-complex)-complex1
w_1_5 = IN(16); %gate-fuel-complex1
w_1_6 = IN(17); %signal-(signal-gate-complex)complex1
w_1_7 = IN(18); %fuel-(input-trigger-complex)complex1
w_1_8 = IN(19); %newtrigger-(input-trigger-complex)complex1


sig2 = IN(20); %signal2
trans2 = IN(21); %transduser2
sig2_trans2 = IN(22);%signal-transduser-complex2
out2 = IN(23); %output2
gate2 = IN(24); %gate 2 
n_tri2 = IN(25); %newtrigger2
sig2_gate2 = IN(26); %signal-gate-complex2
fuel2 = IN(27); %fuel2
w_2_1 = IN(28); %fuel-(signal-gate-complex)complex2
w_2_2 = IN(29); %gate-newtrigger-complex2
w_2_3 = IN(30); %fuel*2-(signal-gate-complex)complex2
w_2_4 = IN(31); %newtrigger-fuel-(signal-gate-complex)-complex2
w_2_5 = IN(32); %gate-fuel-complex2
w_2_6 = IN(33); %signal-(signal-gate-complex)complex2
w_2_7 = IN(34); %fuel-(input-trigger-complex)complex2
w_2_8 = IN(35); %newtrigger-(input-trigger-complex)complex2


sig3 = IN(36); %signal3
trans3 = IN(37); %transduser3
sig3_trans3 = IN(38); %signal-transduser-complex3
out3 = IN(39); %output3
gate3 = IN(40); %gate3
n_tri3 = IN(41); %newtrigger3
sig3_gate3 = IN(42); %signal-gate-complex3
fuel3 = IN(43); %fuel3
w_3_1 = IN(44); %fuel-(signal-gate-complex)complex3
w_3_2 = IN(45); %gate-newtrigger-complex3
w_3_3 = IN(46); %fuel*2-(signal-gate-complex)complex3
w_3_4 = IN(47); %newtrigger-fuel-(signal-gate-complex)-complex3
w_3_5 = IN(48); %gate-fuel-complex3
w_3_6 = IN(49); %signal-(signal-gate-complex)complex3
w_3_7 = IN(50); %fuel-(input-trigger-complex)complex3
w_3_8 = IN(51); %newtrigger-(input-trigger-complex)complex3


sig4 = IN(52); %signal4
trans4 = IN(53); %transduser4
sig4_trans4 = IN(54); %signal-transduser-complex4
out4 = IN(55); %output4
gate4 = IN(56); %gate4
n_tri4 = IN(57); %newtrigger4
sig4_gate4 = IN(58);  %signal-gate-complex4
fuel4 = IN(59); %fuel4
w_4_1 = IN(60); %fuel-(signal-gate-complex)complex4
w_4_2 = IN(61); %gate-newtrigger-complex4
w_4_3 = IN(62); %fuel*2-(signal-gate-complex)complex4
w_4_4 = IN(63); %newtrigger-fuel-(signal-gate-complex)-complex4
w_4_5 = IN(64); %gate-fuel-complex4
w_4_6 = IN(65); %signal-(signal-gate-complex)complex4
w_4_7 = IN(66); %fuel-(input-trigger-complex)complex4
w_4_8 = IN(67); %newtrigger-(input-trigger-complex)complex4


sig5 = IN(68); %signal5
trans5 = IN(69); %transduser5
sig5_trans5 = IN(70); %signal-transduser-complex5
out5 = IN(71); %output5
gate5 = IN(72); %gate5 
n_tri5 = IN(73); %newtrigger5
sig5_gate5 = IN(74); %signal-gate-complex2
fuel5 = IN(75); %fuel5
w_5_1 = IN(76); %fuel-(signal-gate-complex)complex5
w_5_2 = IN(77); %gate-newtrigger-complex5
w_5_3 = IN(78); %fuel*2-(signal-gate-complex)complex5
w_5_4 = IN(79); %newtrigger-fuel-(signal-gate-complex)-complex5
w_5_5 = IN(80); %gate-fuel-complex5
w_5_6 = IN(81); %signal-(signal-gate-complex)complex5
w_5_7 = IN(82); %fuel-(input-trigger-complex)complex5
w_5_8 = IN(83); %newtrigger-(input-trigger-complex)complex5


sig6 = IN(84); %signal6
trans6 = IN(85); %transduser6
sig6_trans6 = IN(86); %signal-transduser-complex6
out6 = IN(87); %outputF
gate6 = IN(88); %gate 6
n_tri6 = IN(89); %newtrigger6
sig6_gate6 = IN(90); %signal-gate-complex6
fuel6 = IN(91); %fuel6
w_6_1 = IN(92); %fuel-(signal-gate-complex)complex6
w_6_2 = IN(93); %gate-newtrigger-complex6
w_6_3 = IN(94); %fuel*2-(signal-gate-complex)complex6
w_6_4 = IN(95); %newtrigger-fuel-(signal-gate-complex)-complex6
w_6_5 = IN(96); %gate-fuel-complex6
w_6_6 = IN(97); %signal-(signal-gate-complex)complex6
w_6_7 = IN(98); %fuel-(input-trigger-complex)complex6
w_6_8 = IN(99); %newtrigger-(input-trigger-complex)complex6


sig7 = IN(100); %signal7
trans7 = IN(101); %transduser7
sig7_trans7 = IN(102); %signal-transduser-complex7
out7 = IN(103); %output7
gate7 = IN(104); %gate7
n_tri7 = IN(105); %newtrigger7
sig7_gate7 = IN(106); %signal-gate-complex7
fuel7 = IN(107); %fuel7
w_7_1 = IN(108); %fuel-(signal-gate-complex)complex7
w_7_2 = IN(109); %gate-newtrigger-complex7
w_7_3 = IN(110); %fuel*2-(signal-gate-complex)complex7
w_7_4 = IN(111); %newtrigger-fuel-(signal-gate-complex)-complex7
w_7_5 = IN(112); %gate-fuel-complex7
w_7_6 = IN(113); %signal-(signal-gate-complex)complex7
w_7_7 = IN(114); %fuel-(input-trigger-complex)complex7


in = IN(115); 

%ThresholdgateA-1
out_ThA1 = IN(116); %ThA1_output=ThB1_input,NOT1_input
fuel_ThA1 = IN(117); %fuel
G_in_ThA1 = IN(118); %gate:input
G_out_ThA1 = IN(119); %gate:output
G_fuel_ThA1 = IN(120); %gate:fuel
th_ThA1 = IN(121); %threshould1 = Vin

%NOTgate-1
Inverter1 = IN(122); %Inverter
G_out_NOT1 = IN(123); %gate:output
G_in_NOT1 = IN(124); %gate:Inverter
out_NOT1 = IN(125); %NOT1_output = AND1_input2
th_NOT1 = IN(126); %threshould_Inverter
G_fuel_NOT1 = IN(127); %gate:fuel
fuel_NOT1 = IN(128); %fuel

%ThresholdgateB-1
out_ThB1 = IN(129); %ThB1_output = AND2_input1
fuel_ThB1 = IN(130); %fuel
G_in_ThB1 = IN(131); %gate:input
G_out_ThB1 = IN(132); %gate:output
G_fuel_ThB1 = IN(133); %gate:fuel
th_ThB1= IN(134); %threshould = Vin

%ThresholdgateA-2
out_ThA2 = IN(135); %ThA2_output = NOT2_input,ThB2_input
fuel_ThA2 = IN(136); %fuel
G_in_ThA2 = IN(137); %gate:input
G_out_ThA2 = IN(138); %gate:output
G_fuel_ThA2 = IN(139); %gate:fuel
th_ThA2 = IN(140); %threshould1 = Vin

%NOTgate-2
Inverter2 = IN(141); %Inverter
G_out_NOT2 = IN(142); %gate:output
G_in_NOT2 = IN(143); %gate:input
out_NOT2 = IN(144); %NOT2_output = AND2_input2
th_NOT2 = IN(145); %threshold_Inverter
G_fuel_NOT2 = IN(146); %gate:fuel
fuel_NOT2 = IN(147); %fuel

%ThresholdgateB-2
out_ThB2 = IN(148); %ThB2_output = AND3_input1
fuel_ThB2 = IN(149); %fuel
G_in_ThB2 = IN(150); %gate:input
G_out_ThB2 = IN(151); %gate:output
G_fuel_ThB2 = IN(152); %gate:fuel
th_ThB2 = IN(153); %threshould

%ThresholdgateA-3
out_ThA3= IN(154); %ThA3_output = NOT3_input,ThB3_input
fuel_ThA3 = IN(155); %fuel
G_in_ThA3 = IN(156); %gate:input
G_out_ThA3 = IN(157); %gate:output
G_fuel_ThA3 = IN(158); %gate:fuel
th_ThA3 = IN(159); %threshould = Vin

%NOTgate-3
Inverter3 = IN(160); %Inverter
G_out_NOT3 = IN(161); %gate:output
G_in_NOT3 = IN(162); %gate:input
out_NOT3 = IN(163); %NOT3_output = AND3_input2
th_NOT3 = IN(164); %threshold_Inverter
G_fuel_NOT3 = IN(165); %gate:fuel
fuel_NOT3 = IN(166); %fuel

%ThresholdgateB-3
out_ThB3 = IN(167); %ThB3_output = AND4_input1
fuel_ThB3 = IN(168); %fuel
G_in_ThB3 = IN(169); %gate:input
G_out_ThB3 = IN(170); %gate:output
G_fuel_ThB3 = IN(171); %gate:fuel
th_ThB3 = IN(172); %threshould

%ThreholdgateA-4
out_ThA4 = IN(173); %ThA4_output = NOT4_input,ThB4_input
fuel_ThA4 = IN(174); %fuel
G_in_ThA4 = IN(175); %gate:input
G_out_ThA4 = IN(176); %gate:output
G_fuel_ThA4 = IN(177); %gate:fuel
th_ThA4= IN(178); %threshould= Vin

%NOTgate4
Inverter4 = IN(179); %Inverter
G_out_NOT4 = IN(180); %gate:output
G_in_NOT4 = IN(181); %gate:input
out_NOT4 = IN(182); %NOT4_output = AND4_input2
th_NOT4 = IN(183); %Threshold_Inverter
G_fuel_NOT4 = IN(184); %gate:fuel
fuel_NOT4 = IN(185); %fuel

%ThresholdgateB-4
out_ThB4 = IN(186); %ThB4_output = AND5_input1
fuel_ThB4 = IN(187); %fuel
G_in_ThB4 = IN(188); %gate:input
G_out_ThB4 = IN(189); %gate:output
G_fuel_ThB4 = IN(190); %gate:fuel
th_ThB4 = IN(191); %threshould

%ThreholdgateA-5
out_ThA5= IN(192); %ThA5_output = NOT5_input,ThB5_input
fuel_ThA5 = IN(193); %fuel
G_in_ThA5= IN(194); %gate:input
G_out_ThA5 = IN(195); %gate:output
G_fuel_ThA5 = IN(196); %gate:fuel
th_ThA5 = IN(197); %threshould = Vin

%NOTgate5
Inverter5 = IN(198); %Inverter
G_out_NOT5 = IN(199); %gate:output
G_in_NOT5 = IN(200); %gate:input
out_NOT5 = IN(201); %NOT5_output = AND5_input2
th_NOT5 = IN(202); %Threshold_Inverter
G_fuel_NOT5 = IN(203); %gate:fuel
fuel_NOT5 = IN(204); %fuel

%ThresholdgateB-5
out_ThB5 = IN(205); %ThB5_output = AND6_input1
fuel_ThB5 = IN(206); %fuel
G_in_ThB5 = IN(207); %gate:input
G_out_ThB5 = IN(208); %gate:output
G_fuel_ThB5 = IN(209); %gate:fuel
th_ThB5 = IN(210); %threshould

%ThreholdgateA-6
out_ThA6 = IN(211); %ThA6_output = NOT6_input,ThB6_input
fuel_ThA6 = IN(212); %fuel
G_in_ThA6 = IN(213); %gate:input
G_out_ThA6 = IN(214); %gate:output
G_fuel_ThA6 = IN(215); %gate:fuel
th_ThA6 = IN(216); %threshould = Vin

%NOTgate6
Inverter6 = IN(217); %Inverter
G_out_NOT6 = IN(218); %gate:output
G_in_NOT6 = IN(219); %gate:input
out_NOT6 = IN(220); %NOT6_output = AND6_input2
th_NOT6 = IN(221); %Threshold_Inverter
G_fuel_NOT6 = IN(222); %gate:fuel
fuel_NOT6 = IN(223); %fuel

%ThresholdgateB-6
out_ThB6 = IN(224);  %ThB6_output = AND7_input1
fuel_ThB6 = IN(225); %fuel
G_in_ThB6 = IN(226); %gate:input
G_out_ThB6 = IN(227); %gate:output
G_fuel_ThB6 = IN(228); %gate:fuel
th_ThB6 = IN(229); %threshould


%ThreholdgateA-7
out_ThA7 = IN(230); %ThA7_output = NOT7_input,ThB7_input
fuel_ThA7 = IN(231); %fuel
G_in_ThA7 = IN(232); %gate:input
G_out_ThA7 = IN(233); %gate:output
G_fuel_ThA7 = IN(234); %gate:fuel
th_ThA7 = IN(235); %threshould = Vin

%NOTgate7
Inverter7 = IN(236); %Inverter
G_out_NOT7 = IN(237); %gate:output
G_in_NOT7 = IN(238); %gate:input
out_NOT7 = IN(239); %NOT7_output = AND7_input2
th_NOT7 = IN(240); %Threshold_Inverter
G_fuel_NOT7 = IN(241); %gate:fuel
fuel_NOT7 = IN(242); %fuel

%ThresholdgateB-7
out_ThB7 = IN(243); %ThB7_output = AND8_input1
fuel_ThB7 = IN(244); %fuel
G_in_ThB7 = IN(245); %gate:input
G_out_ThB7 = IN(246); %gate:output
G_fuel_ThB7 = IN(247); %gate:fuel
th_ThB7 = IN(248); %threshould


%ThreholdgateA-8
out_ThA8 = IN(249); %ThA8_output = NOT8_input,ThB8_input    
fuel_ThA8 = IN(250); %fuel
G_in_ThA8 = IN(251); %gate:input
G_out_ThA8 = IN(252); %gate:output
G_fuel_ThA8 = IN(253); %gate:fuel
th_ThA8 = IN(254); %threshould = Vin

%NOTgate8
Inverter8 = IN(255); %Inverter
G_out_NOT8 = IN(256); %gate:output
G_in_NOT8 = IN(257); %gate:input
out_NOT8 = IN(258); %NOT8_output = AND8_input2
th_NOT8 = IN(259); %Threshold_Inverter
G_fuel_NOT8 = IN(260); %gate:fuel
fuel_NOT8 = IN(261); %fuel


% ANDgate1
out_g1_AND1 = IN(262); %g1_output = g4_input
out_g3_AND1 = IN(263); %g3_output = g1_input2
G1_in1_AND1 = IN(264); %g1_gate:input1
G1_out_AND1 = IN(265); %g1_gate:output
G1_in2_AND1 = IN(266); %g1_gate:input2
th1_g1_AND1 = IN(267); %g1_threshould_input1
th_g4_AND1 = IN(268); %g4_threshould
th2_g1_AND1 = IN(269); %g1_threshould_input2

out_g2_AND1 = IN(270); %g2_output = g3_input
fuel_g2_AND1 = IN(271); %g2_fuel
G2_in_AND1 = IN(272); %g2_gate:input
G2_out_AND1 = IN(273); %g2_gate:output
G2_fuel_AND1 = IN(274); %g2_gate:fuel
th_g2_AND1 = IN(275); %g2_threshould
th_g3_AND1 = IN(276); %g3_threshould

waste_AND1 = IN(277); %waste
G3_out_AND1 = IN(278); %g3_gate:output
G3_in_AND1 = IN(279); %g3_gate:input
G3_waste_AND1 = IN(280); %g3_gate:waste

out_AND1 = IN(281); %AND1_output = OR1_input1
fuel_g4_AND1 = IN(282); %g4_fuel
G4_in_AND1 = IN(283); %g4_gate:input
G4_out_AND1 = IN(284); %g4_gate:output
G4_fuel_AND1= IN(285); %g4_gate:fuel


% ANDgate2
out_g1_AND2 = IN(286); %g1_output = g4_input
out_g3_AND2 = IN(287); %g3_output = g1_input2
G1_in1_AND2 = IN(288); %g1_gate:input1
G1_out_AND2 = IN(289); %g1_gate:output
G1_in2_AND2 = IN(290); %g1_gate:input2
th1_g1_AND2 = IN(291); %g1_threshould_input1
th_g4_AND2 = IN(292); %g4_threshould
th2_g1_AND2 = IN(293); %Ag1_threshould_input2

out_g2_AND2 = IN(294); %g2_output = g3_input 
fuel_g2_AND2 = IN(295); %g2_fuel
G2_in_AND2 = IN(296); %g2_gate:input
G2_out_AND2 = IN(297); %g2_gate:output
G2_fuel_AND2 = IN(298); %g2_gate:fuel 
th_g2_AND2 = IN(299); %g2_threshould
th_g3_AND2 = IN(300); %g3_threshould

waste_AND2 = IN(301); %waste
G3_out_AND2 = IN(302); %g3_gate:output
G3_in_AND2 = IN(303); %g3_gate:input
G3_waste_AND2 = IN(304); %g3_gate:waste

out_AND2 = IN(305); %AND2_output = OR1_input2
fuel_g4_AND2 = IN(306); %g4_fuel
G4_in_AND2 = IN(307); %g4_gate:input
G4_out_AND2 = IN(308); %g4_gate:output
G4_fuel_AND2 = IN(309); %g4_gate:fuel


% ANDgate3
out_g1_AND3 = IN(310); %g1_output = g4_input
out_g3_AND3 = IN(311); %g3_output = g1_input2
G1_in1_AND3 = IN(312); %g1_gate:input1
G1_out_AND3 = IN(313); %g1_gate:output
G1_in2_AND3 = IN(314); %g1_gate:input2
th1_g1_AND3 = IN(315); %g1_threshould_input1
th_g4_AND3 = IN(316); %g4_threshould
th2_g1_AND3 = IN(317); %g1_threshould_input2

out_g2_AND3 = IN(318); %g2_output = g3_input 
fuel_g2_AND3 = IN(319); %g2_fuel
G2_in_AND3 = IN(320); %g2_gate:input
G2_out_AND3= IN(321); %g2_gate:output
G2_fuel_AND3 = IN(322); %g2_gate:fuel
th_g2_AND3= IN(323); %g2_threshould
th_g3_AND3 = IN(324); %g3_threshould

waste_AND3 = IN(325); %waste
G3_out_AND3 = IN(326); %g3_gate:output
G3_in_AND3 = IN(327); %g3_gate:input
G3_waste_AND3 = IN(328); %g3_gate:waste

out_AND3 = IN(329); %AND3_output = OR2_input1
fuel_g4_AND3 = IN(330); %g4_fuel
G4_in_AND3 = IN(331); %g4_gate:input
G4_out_AND3 = IN(332); %g4_gate:output
G4_fuel_AND3 = IN(333); %g4_gate:fuel


% ANDgate4
out_g1_AND4 = IN(334); %g1_output = g4_input
out_g3_AND4= IN(335); %g3_output = g1_input2
G1_in1_AND4 = IN(336); %g1_gate:input1
G1_out_AND4 = IN(337); %g1_gate:output
G1_in2_AND4 = IN(338); %g1_gate:input2
th1_g1_AND4 = IN(339); %g1_threshould_input1
th_g4_AND4 = IN(340); %g4_threshould
th2_g1_AND4 = IN(341); %g1_threshould_input2

out_g2_AND4 = IN(342); %g2_output = g3_input 
fuel_g2_AND4 = IN(343); %g2_fuel
G2_in_AND4 = IN(344); %g2_gate:input
G2_out_AND4 = IN(345); %g2_gate:output
G2_fuel_AND4 = IN(346); %g2_gate:fuel
th_g2_AND4 = IN(347); %g2_threshould
th_g3_AND4 = IN(348); %g3_threshould

waste_AND4 = IN(349); %waste
G3_out_AND4 = IN(350); %g3_gate:output
G3_in_AND4 = IN(351); %g3_gate:input
G3_waste_AND4 = IN(352); %g3_gate:waste

out_AND4 = IN(353); %AND4_output = OR2_input2
fuel_g4_AND4 = IN(354); %g4_fuel
G4_in_AND4 = IN(355); %g4_gate:input
G4_out_AND4 = IN(356); %g4_gate:output
G4_fuel_AND4 = IN(357); %g4_gate:fuel


% ANDgate5
out_g1_AND5 = IN(358); %g1_output = g4_input
out_g3_AND5 = IN(359); %g3_output = g1_input2
G1_in1_AND5 = IN(360); %g1_gate:input1
G1_out_AND5 = IN(361); %g1_gate:output
G1_in2_AND5 = IN(362); %g1_gate:input2
th1_g1_AND5 = IN(363); %g1_threshould_input1
th_g4_AND5 = IN(364); %g4_threshould
th2_g1_AND5 = IN(365); %g1_threshould_input2

out_g2_AND5 = IN(366); %g2_output = g3_input  
fuel_g2_AND5 = IN(367); %g2_fuel
G2_in_AND5 = IN(368); %g2_gate:input
G2_out_AND5 = IN(369); %g2_gate:output
G2_fuel_AND5 = IN(370); %g2_gate:fuel
th_g2_AND5 = IN(371); %g2_threshould
th_g3_AND5 = IN(372); %g3_threshould

waste_AND5 = IN(373); %waste 
G3_out_AND5 = IN(374); %g3_gate:output
G3_in_AND5 = IN(375); %g3_gate:input
G3_waste_AND5 = IN(376); %g3_gate:waste

out_AND5 = IN(377); %AND5_output = OR2_input2
fuel_g4_AND5 = IN(378); %g4_fuel
G4_in_AND5 = IN(379); %g4_gate:input
G4_out_AND5 = IN(380); %g4_gate:output
G4_fuel_AND5 = IN(381); %g4_gate:fuel


% ANDgate6
out_g1_AND6 = IN(382); %g1_output = g4_input
out_g3_AND6 = IN(383); %g3_output = g1_input2
G1_in1_AND6 = IN(384); %g1_gate:input1
G1_out_AND6 = IN(385); %g1_gate:output
G1_in2_AND6 = IN(386); %g1_gate:input2
th1_g1_AND6 = IN(387); %g1_threshould_input1
th_g4_AND6 = IN(388); %g4_threshould
th2_g1_AND6 = IN(389); %g1_threshould_input2

out_g2_AND6 = IN(390); %g2_output = g3_input  
fuel_g2_AND6 = IN(391); %g2_fuel
G2_in_AND6 = IN(392); %g2_gate:input
G2_out_AND6 = IN(393); %g2_gate:output
G2_fuel_AND6 = IN(394); %g2_gate:fuel
th_g2_AND6 = IN(395); %g2_threshould
th_g3_AND6 = IN(396); %g3_threshould

waste_AND6 = IN(397); %waste
G3_out_AND6 = IN(398); %g3_gate:output
G3_in_AND6 = IN(399); %g3_gate:input
G3_waste_AND6 = IN(400); %g3_gate:waste

out_AND6 = IN(401); %AND6_output = OR2_input2
fuel_g4_AND6 = IN(402); %g4_fuel
G4_in_AND6 = IN(403); %g4_gate:input
G4_out_AND6 = IN(404); %g4_gate:output
G4_fuel_AND6 = IN(405); %g4_gate:fuel


% ANDgate7
out_g1_AND7 = IN(406); %g1_output = g4_input
out_g3_AND7 = IN(407); %g3_output = g1_input2
G1_in1_AND7 = IN(408); %g1_gate:input1
G1_out_AND7 = IN(409); %g1_gate:output
G1_in2_AND7 = IN(410); %g1_gate:input2
th1_g1_AND7 = IN(411); %g1_threshould_input1
th_g4_AND7 = IN(412); %g4_threshould
th2_g1_AND7 = IN(413); %g1_threshould_input2

out_g2_AND7 = IN(414); %g2_output = g3_input  
fuel_g2_AND7 = IN(415); %g2_fuel
G2_in_AND7 = IN(416); %g2_gate:input
G2_out_AND7 = IN(417); %g2_gate:output
G2_fuel_AND7 = IN(418); %g2_gate:fuel
th_g2_AND7 = IN(419); %g2_threshould
th_g3_AND7 = IN(420); %g3_threshould

waste_AND7 = IN(421); %waste
G3_out_AND7 = IN(422); %g3_gate:output
G3_in_AND7 = IN(423); %g3_gate:input
G3_waste_AND7 = IN(424); %g3_gate:waste

out_AND7 = IN(425); %AND7_output = OR2_input2
fuel_g4_AND7 = IN(426); %g4_fuel
G4_in_AND7 = IN(427); %g4_gate:input
G4_out_AND7 = IN(428); %g4_gate:output
G4_fuel_AND7 = IN(429); %g4_gate:fuel


% ANDgate8 
out_g1_AND8 = IN(430); %g1_output = g4_input
out_g3_AND8 = IN(431); %g3_output = g1_input2
G1_in1_AND8 = IN(432); %g1_gate:input1
G1_out_AND8 = IN(433); %g1_gate:output
G1_in2_AND8 = IN(434); %g1_gate:input2
th1_g1_AND8 = IN(435); %g1_threshould_input1
th_g4_AND8 = IN(436); %g4_threshould
th2_g1_AND8 = IN(437); %g1_threshould_input2

out_g2_AND8 = IN(438); %g2_output = g3_input 
fuel_g2_AND8 = IN(439); %g2_fuel
G2_in_AND8 = IN(440); %g2_gate:input
G2_out_AND8 = IN(441); %g2_gate:output
G2_fuel_AND8 = IN(442); %g2_gate:fuel
th_g2_AND8 = IN(443); %g2_threshould
th_g3_AND8 = IN(444); %g3_threshould

waste_AND8 = IN(445); %waste 
G3_out_AND8 = IN(446); %g3_gate:output
G3_in_AND8 = IN(447); %g3_gate:input
G3_waste_AND8 = IN(448); %g3_gate:waste

out_AND8 = IN(449); %AND8_output = OR2_input2
fuel_g4_AND8 = IN(450); %g4_fuel
G4_in_AND8 = IN(451); %g4_gate:input
G4_out_AND8 = IN(452); %g4_gate:output
G4_fuel_AND8 = IN(453); %g4_gate:fuel



X2 = IN(454); %output2
X1 = IN(455); %output1
X0 = IN(456); %output0
fuel = IN(457); %fuel
g_in7 = IN(458); %gate:input7
g_in6 = IN(459); %gate:input6
g_in5 = IN(460); %gate:input5
g_in4 = IN(461); %gate:input4
g_in3 = IN(462); %gate:input3
g_in2 = IN(463); %gate:input2
g_in1 = IN(464); %gate:input1
g_out2 = IN(465); %gate:output2
g_out1 = IN(466); %gate:output1
g_out0 = IN(467); %gate:output0
g_fuel = IN(468); %gate:fuel
th07 = IN(469);
th06 = IN(470);
th05 = IN(471);
th04 = IN(472);
th03 = IN(473);
th02 = IN(474);
th01 = IN(475);

input2 = IN(476);


%ThresholdgateA-1
v1 = ks * (out1 * G_out_ThA1 - out_ThA1 * G_in_ThA1);
v2 = ks * (fuel_ThA1 * G_in_ThA1 - out1 * G_fuel_ThA1);
v3 = kf * out1 * th_ThA1;

%NOTgate-1
v4 = km * (Inverter1 * out_ThA1);
v5 = ks * (Inverter1 * G_out_NOT1 - out_NOT1 * G_in_NOT1);
v6= kf * (Inverter1 * th_NOT1);
v7 = ks * (Inverter1 * G_fuel_NOT1  - fuel_NOT1 * G_in_NOT1);

%ThresholdgateB-1
v8 = ks * (out_ThA1 * G_out_ThB1 - out_ThB1 * G_in_ThB1);
v9= ks * (fuel_ThB1 * G_in_ThB1 - out_ThA1 * G_fuel_ThB1);
v10 = kf * out_ThA1 * th_ThB1;


%ThresholdgateA-2
v11 = ks * (out2 * G_out_ThA2 - out_ThA2 * G_in_ThA2);
v12 = ks * (fuel_ThA2 * G_in_ThA2 - out2 * G_fuel_ThA2);
v13= kf * out2 * th_ThA2;

%NOTgate-2
v14 = km * (Inverter2 * out_ThA2);
v15 = ks * (Inverter2 * G_out_NOT2 - out_NOT2 * G_in_NOT2);
v16= kf * (Inverter2 * th_NOT2);
v17 = ks * (Inverter2 * G_fuel_NOT2  - fuel_NOT2 * G_in_NOT2);

%ThresholdgateB-2
v18 = ks * (out_ThA2 * G_out_ThB2 - out_ThB2 * G_in_ThB2);
v19= ks * (fuel_ThB2 * G_in_ThB2 - out_ThA2 * G_fuel_ThB2);
v20 = kf * out_ThA2 * th_ThB2;


%ThresholdgateA-3
v21 = ks * (out3 * G_out_ThA3 - out_ThA3* G_in_ThA3);
v22 = ks * (fuel_ThA3 * G_in_ThA3 - out3 * G_fuel_ThA3);
v23= kf * out3 * th_ThA3;

%NOTgate-3
v24 = km * (Inverter3 * out_ThA3);
v25 = ks * (Inverter3 * G_out_NOT3 - out_NOT3 * G_in_NOT3);
v26= kf * (Inverter3 * th_NOT3);
v27 = ks * (Inverter3 * G_fuel_NOT3  - fuel_NOT3 * G_in_NOT3);

%ThresholdgateB-3
v28 = ks * (out_ThA3* G_out_ThB3 - out_ThB3 * G_in_ThB3);
v29= ks * (fuel_ThB3 * G_in_ThB3 - out_ThA3* G_fuel_ThB3);
v30 = kf * out_ThA3* th_ThB3;


%ThresholdgateA-4
v31 = ks * (out4 * G_out_ThA4 - out_ThA4 * G_in_ThA4);
v32 = ks * (fuel_ThA4 * G_in_ThA4 - out4 * G_fuel_ThA4);
v33 = kf * out4 * th_ThA4;

%NOTgate-4
v34 = km * (Inverter4 * out_ThA4);
v35 = ks * (Inverter4 * G_out_NOT4 - out_NOT4 * G_in_NOT4);
v36 = kf * (Inverter4 * th_NOT4);
v37 = ks * (Inverter4 * G_fuel_NOT4  - fuel_NOT4 * G_in_NOT4);

%ThresholdgateB-4
v38 = ks * (out_ThA4 * G_out_ThB4 - out_ThB4 * G_in_ThB4);
v39 = ks * (fuel_ThB4 * G_in_ThB4 - out_ThA4 * G_fuel_ThB4);
v40 = kf * out_ThA4 * th_ThB4;


%ThresholdgateA-5
v41 = ks * (out5 * G_out_ThA5 - out_ThA5* G_in_ThA5);
v42 = ks * (fuel_ThA5 * G_in_ThA5- out5 * G_fuel_ThA5);
v43= kf * out5 * th_ThA5;

%NOTgate-5
v44 = km * (Inverter5 * out_ThA5);
v45 = ks * (Inverter5 * G_out_NOT5 - out_NOT5 * G_in_NOT5);
v46= kf * (Inverter5 * th_NOT5);
v47 = ks * (Inverter5 * G_fuel_NOT5  - fuel_NOT5 * G_in_NOT5);

%ThresholdgateB-5
v48 = ks * (out_ThA5* G_out_ThB5 - out_ThB5 * G_in_ThB5);
v49= ks * (fuel_ThB5 * G_in_ThB5 - out_ThA5* G_fuel_ThB5);
v50 = kf * out_ThA5* th_ThB5;


%ThresholdgateA-6
v51 = ks * (out6 * G_out_ThA6 - out_ThA6 * G_in_ThA6);
v52 = ks * (fuel_ThA6 * G_in_ThA6 - out6 * G_fuel_ThA6);
v53= kf * out6 * th_ThA6;

%NOTgate-6
v54 = km * (Inverter6 * out_ThA6);
v55 = ks * (Inverter6 * G_out_NOT6 - out_NOT6 * G_in_NOT6);
v56= kf * (Inverter6 * th_NOT6);
v57 = ks * (Inverter6 * G_fuel_NOT6  - fuel_NOT6 * G_in_NOT6);

%ThresholdgateB-6
v58 = ks * (out_ThA6 * G_out_ThB6 - out_ThB6 * G_in_ThB6);
v59= ks * (fuel_ThB6 * G_in_ThB6 - out_ThA6 * G_fuel_ThB6);
v60 = kf * out_ThA6 * th_ThB6;


%ThresholdgateA-7
v61 = ks * (out7 * G_out_ThA7 - out_ThA7 * G_in_ThA7);
v62 = ks * (fuel_ThA7 * G_in_ThA7 - out7 * G_fuel_ThA7);
v63= kf * out7 * th_ThA7;

%NOTgate-7
v64 = km * (Inverter7 * out_ThA7);
v65 = ks * (Inverter7 * G_out_NOT7 - out_NOT7 * G_in_NOT7);
v66= kf * (Inverter7 * th_NOT7);
v67 = ks * (Inverter7 * G_fuel_NOT7  - fuel_NOT7 * G_in_NOT7);

%ThresholdgateB-7
v68 = ks * (out_ThA7 * G_out_ThB7 - out_ThB7 * G_in_ThB7);
v69= ks * (fuel_ThB7 * G_in_ThB7 - out_ThA7 * G_fuel_ThB7);
v70 = kf * out_ThA7 * th_ThB7;


%ThresholdgateA-8
v71 = ks * (input2 * G_out_ThA8 - out_ThA8 * G_in_ThA8);
v72 = ks * (fuel_ThA8 * G_in_ThA8 - input2 * G_fuel_ThA8);
v73= kf * input2 * th_ThA8;

%NOTgate-8
v74 = km * (Inverter8 * out_ThA8);
v75 = ks * (Inverter8 * G_out_NOT8 - out_NOT8 * G_in_NOT8);
v76= kf * (Inverter8 * th_NOT8);
v77 = ks * (Inverter8 * G_fuel_NOT8  - fuel_NOT8 * G_in_NOT8);


%--------------------------------------------------


%ANDgate-1
v78 = ks * (in * G1_out_AND1  - out_g1_AND1 * G1_in1_AND1);
v79 = ks * (out_g3_AND1 * G1_in1_AND1 - in * G1_in2_AND1);
v80 = kf * in * th1_g1_AND1;

v81 = kf * out_g1_AND1 * th_g4_AND1;
v82 = kf * out_g3_AND1 * th2_g1_AND1;

v83 = ks * (out_NOT1 * G2_out_AND1 - out_g2_AND1 * G2_in_AND1);
v84 = ks * (fuel_g2_AND1 * G2_in_AND1 - out_NOT1 * G2_fuel_AND1);
v85 = kf * out_NOT1 * th_g2_AND1;
v86 = kf * out_g2_AND1 * th_g3_AND1;

v87 = ks * (out_g3_AND1 * G3_waste_AND1 - waste_AND1 * G3_out_AND1);
v88 = ks * (out_g2_AND1 * G3_waste_AND1 - waste_AND1 * G3_in_AND1);

v89 = ks * (out_g1_AND1 * G4_out_AND1 - out_AND1 * G4_in_AND1);
v90 = ks * (fuel_g4_AND1 * G4_in_AND1 - out_g1_AND1 * G4_fuel_AND1);


% ANDgate-2
v91 = ks * (out_ThB1 * G1_out_AND2 - out_g1_AND2 * G1_in1_AND2);
v92 = ks * (out_g3_AND2 * G1_in1_AND2 - out_ThB1 * G1_in2_AND2 );
v93 = kf * out_ThB1 * th1_g1_AND2;
v94 = kf * out_g1_AND2 * th_g4_AND2;
v95 = kf * out_g3_AND2 * th2_g1_AND2;

v96 = ks * (out_NOT2 * G2_out_AND2 - out_g2_AND2 * G2_in_AND2);
v97 = ks * (fuel_g2_AND2 * G2_in_AND2 - out_NOT2 * G2_fuel_AND2);
v98 = kf * out_NOT2 * th_g2_AND2;
v99 = kf * out_g2_AND2 * th_g3_AND2;

v100 = ks * (out_g3_AND2 * G3_waste_AND2 - waste_AND2 * G3_out_AND2);
v101 = ks * (out_g2_AND2 * G3_waste_AND2 - waste_AND2 * G3_in_AND2);

v102 = ks * (out_g1_AND2 * G4_out_AND2 - out_AND2 * G4_in_AND2);
v103 = ks * (fuel_g4_AND2 * G4_in_AND2 - out_g1_AND2 * G4_fuel_AND2);


% ANDgate-3
v104 = ks * (out_ThB2 * G1_out_AND3 - out_g1_AND3 * G1_in1_AND3);
v105 = ks * (out_g3_AND3 * G1_in1_AND3 - out_ThB2 * G1_in2_AND3);
v106 = kf * out_ThB2 * th1_g1_AND3;
v107 = kf * out_g1_AND3 * th_g4_AND3;
v108 = kf * out_g3_AND3 * th2_g1_AND3;

v109 = ks * (out_NOT3 * G2_out_AND3- out_g2_AND3 * G2_in_AND3);
v110 = ks * (fuel_g2_AND3 * G2_in_AND3 - out_NOT3 * G2_fuel_AND3);
v111 = kf * out_NOT3 * th_g2_AND3;
v112 = kf * out_g2_AND3 * th_g3_AND3;

v113 = ks * (out_g3_AND3 * G3_waste_AND3 - waste_AND3 * G3_out_AND3);
v114 = ks * (out_g2_AND3 * G3_waste_AND3 - waste_AND3 * G3_in_AND3);

v115 = ks * (out_g1_AND3 * G4_out_AND3 - out_AND3 * G4_in_AND3);
v116 = ks * (fuel_g4_AND3 * G4_in_AND3 - out_g1_AND3 * G4_fuel_AND3);


% ANDgate-4
v117 = ks * (out_ThB3 * G1_out_AND4 - out_g1_AND4 * G1_in1_AND4);
v118 = ks * (out_g3_AND4* G1_in1_AND4 - out_ThB3 * G1_in2_AND4);
v119 = kf * out_ThB3 * th1_g1_AND4;
v120 = kf * out_g1_AND4 * th_g4_AND4;
v121 = kf * out_g3_AND4* th2_g1_AND4;

v122 = ks * (out_NOT4 * G2_out_AND4 - out_g2_AND4 * G2_in_AND4);
v123 = ks * (fuel_g2_AND4 * G2_in_AND4 - out_NOT4 * G2_fuel_AND4);
v124 = kf * out_NOT4 * th_g2_AND4;
v125 = kf * out_g2_AND4 * th_g3_AND4;

v126 = ks * (out_g3_AND4* G3_waste_AND4 - waste_AND4 * G3_out_AND4);
v127 = ks * (out_g2_AND4 * G3_waste_AND4 - waste_AND4 * G3_in_AND4);

v128 = ks * (out_g1_AND4 * G4_out_AND4 - out_AND4 * G4_in_AND4);
v129 = ks * (fuel_g4_AND4 * G4_in_AND4 - out_g1_AND4 * G4_fuel_AND4);



%ANDgate-5
v130 = ks * (out_ThB4 * G1_out_AND5 - out_g1_AND5 * G1_in1_AND5);
v131 = ks * (out_g3_AND5 * G1_in1_AND5 - out_ThB4 * G1_in2_AND5);
v132 = kf * out_ThB4 * th1_g1_AND5;
v133 = kf * out_g1_AND5 * th_g4_AND5;
v134 = kf * out_g3_AND5 * th2_g1_AND5;

v135 = ks * (out_NOT5 * G2_out_AND5 - out_g2_AND5 * G2_in_AND5);
v136 = ks * (fuel_g2_AND5 * G2_in_AND5 - out_NOT5 * G2_fuel_AND5);
v137 = kf * out_NOT5 * th_g2_AND5;
v138 = kf * out_g2_AND5 * th_g3_AND5;

v139 = ks * (out_g3_AND5 * G3_waste_AND5 - waste_AND5 * G3_out_AND5);
v140 = ks * (out_g2_AND5 * G3_waste_AND5 - waste_AND5 * G3_in_AND5);

v141 = ks * (out_g1_AND5 * G4_out_AND5 - out_AND5 * G4_in_AND5);
v142 = ks * (fuel_g4_AND5 * G4_in_AND5 - out_g1_AND5 * G4_fuel_AND5);


% ANDgate-6
v143 = ks * (out_ThB5 * G1_out_AND6 - out_g1_AND6 * G1_in1_AND6);
v144 = ks * (out_g3_AND6 * G1_in1_AND6 - out_ThB5 * G1_in2_AND6);
v145 = kf * out_ThB5 * th1_g1_AND6;
v146 = kf * out_g1_AND6 * th_g4_AND6;
v147 = kf * out_g3_AND6 * th2_g1_AND6;

v148 = ks * (out_NOT6 * G2_out_AND6 - out_g2_AND6 * G2_in_AND6);
v149 = ks * (fuel_g2_AND6 * G2_in_AND6 - out_NOT6 * G2_fuel_AND6);
v150 = kf * out_NOT6 * th_g2_AND6;
v151 = kf * out_g2_AND6 * th_g3_AND6;

v152 = ks * (out_g3_AND6 * G3_waste_AND6 - waste_AND6 * G3_out_AND6);
v153 = ks * (out_g2_AND6 * G3_waste_AND6 - waste_AND6 * G3_in_AND6);

v154 = ks * (out_g1_AND6 * G4_out_AND6 - out_AND6 * G4_in_AND6);
v155 = ks * (fuel_g4_AND6 * G4_in_AND6 - out_g1_AND6 * G4_fuel_AND6);


% ANDgate7
v156 = ks * (out_ThB6 * G1_out_AND7 - out_g1_AND7 * G1_in1_AND7);
v157 = ks * (out_g3_AND7 * G1_in1_AND7 - out_ThB6 * G1_in2_AND7);
v158 = kf * out_ThB6 * th1_g1_AND7;
v159 = kf * out_g1_AND7 * th_g4_AND7;
v160 = kf * out_g3_AND7 * th2_g1_AND7;

v161 = ks * (out_NOT7 * G2_out_AND7 - out_g2_AND7 * G2_in_AND7);
v162 = ks * (fuel_g2_AND7 * G2_in_AND7 - out_NOT7 * G2_fuel_AND7);
v163 = kf * out_NOT7 * th_g2_AND7;
v164 = kf * out_g2_AND7 * th_g3_AND7;

v165 = ks * (out_g3_AND7 * G3_waste_AND7 - waste_AND7 * G3_out_AND7);
v166 = ks * (out_g2_AND7 * G3_waste_AND7 - waste_AND7 * G3_in_AND7);

v167 = ks * (out_g1_AND7 * G4_out_AND7 - out_AND7 * G4_in_AND7);
v168 = ks * (fuel_g4_AND7 * G4_in_AND7 - out_g1_AND7 * G4_fuel_AND7);


% ANDgate-8
v169 = ks * (out_ThB7 * G1_out_AND8 - out_g1_AND8 * G1_in1_AND8);
v170 = ks * (out_g3_AND8 * G1_in1_AND8 - out_ThB7 * G1_in2_AND8);
v171 = kf * out_ThB7 * th1_g1_AND8;
v172 = kf * out_g1_AND8 * th_g4_AND8;
v173 = kf * out_g3_AND8 * th2_g1_AND8;

v174 = ks * (out_NOT8 * G2_out_AND8 - out_g2_AND8 * G2_in_AND8);
v175 = ks * (fuel_g2_AND8 * G2_in_AND8 - out_NOT8 * G2_fuel_AND8);
v176 = kf * out_NOT8 * th_g2_AND8;
v177 = kf * out_g2_AND8 * th_g3_AND8;

v178 = ks * (out_g3_AND8 * G3_waste_AND8 - waste_AND8 * G3_out_AND8);
v179 = ks * (out_g2_AND8 * G3_waste_AND8 - waste_AND8 * G3_in_AND8);

v180 = ks * (out_g1_AND8 * G4_out_AND8 - out_AND8 * G4_in_AND8);
v181 = ks * (fuel_g4_AND8 * G4_in_AND8 - out_g1_AND8 * G4_fuel_AND8);

%--------------------------------------------------

%ORgate
v182 = ks * (out_AND1 * g_out2 - X2 * g_in7);
v183 = ks * (out_AND1 * g_out1 - X1 * g_in7);
v184 = ks * (out_AND1 * g_out0 - X0 * g_in7);
v185 = ks * (fuel * g_in7 - out_AND1 * g_fuel);
v186 = kf * out_AND1 * th07;

v187 = ks * (out_AND2 * g_out2 - X2 * g_in6);
v188 = ks * (out_AND2 * g_out1 - X1 * g_in6);
v189 = ks * (fuel * g_in6 - out_AND2 * g_fuel);
v190 = kf * out_AND2 * th06;

v191 = ks * (out_AND3 * g_out2 - X2 * g_in5);
v192 = ks * (out_AND3 * g_out0 - X0 * g_in5);
v193 = ks * (fuel * g_in5 - out_AND3 * g_fuel);
v194 = kf * out_AND3 * th05;

v195 = ks * (out_AND4 * g_out2 - X2 * g_in4);
v196 = ks * (fuel * g_in4 - out_AND4 * g_fuel);
v197 = kf * out_AND4 * th04;

v198 = ks * (out_AND5 * g_out1 - X1 * g_in3);
v199 = ks * (out_AND5 * g_out0 - X0 * g_in3);
v200 = ks * (fuel * g_in3 - out_AND5 * g_fuel);
v201 = kf * out_AND5 * th03;

v202 = ks * (out_AND6 * g_out1 - X1 * g_in2);
v203 = ks * (fuel * g_in2 - out_AND6 * g_fuel);
v204 = kf * out_AND6 * th02;

v205 = ks * (out_AND7 * g_out0 - X0 * g_in1);
v206 = ks * (fuel * g_in1 - out_AND7 * g_fuel);
v207 = kf * out_AND7 * th01;



f(1) = -ks*in1*tri1+ks*in1_tri1*sig1;
f(2) = -ks*in1*tri1+ks*in1_tri1*sig1;
f(3) = ks*in1*tri1-ks*in1_tri1*sig1-kf*in1_tri1*fuel1+krf*w_1_7- ks*in1_tri1*n_tri1+ks*w_1_8*sig2;
f(4) = ks*in1*tri1-ks*in1_tri1*sig1-kf*sig1*trans1-ks*sig1*gate1+ks*n_tri1*sig1_gate1+ks*sig1_gate1*fuel1-ks*sig1*w_1_1- kf*sig1*sig1_gate1+krf*w_1_6;
f(5) = -kf*sig1*trans1;
f(6) = kf*sig1*trans1; 
f(7) = kf*sig1*trans1-v1+v2-v3;
f(8) = -ks*sig1*gate1+ks*n_tri1*sig1_gate1-kf*gate1*n_tri1+krf*w_1_2- kf*gate1*fuel1+krf*w_1_5;
f(9) = ks*sig1*gate1-ks*n_tri1*sig1_gate1-kf*gate1*n_tri1+krf*w_1_2- kf*n_tri1*w_1_1+krf*w_1_4-ks*in1_tri1*n_tri1+ks*w_1_8*sig2;
f(10) = ks*sig1*gate1-ks*n_tri1*sig1_gate1- ks*sig1_gate1*fuel1+ks*sig1*w_1_1-kf*sig1*sig1_gate1+krf*w_1_6;
f(11) = -ks*sig1_gate1*fuel1+ks*sig1*w_1_1-kf*fuel1*w_1_1+krf*w_1_3- kf*gate1*fuel1+krf*w_1_5-kf*in1_tri1*fuel1+krf*w_1_7;
f(12) = -ks*sig1*w_1_1+ks*sig1_gate1*fuel1-kf*fuel1*w_1_1+krf*w_1_3- kf*n_tri1*w_1_1+krf*w_1_4;
f(13) = kf*gate1*n_tri1-krf*w_1_2;
f(14) = kf*fuel1*w_1_1-krf*w_1_3;
f(15) = kf*n_tri1*w_1_1-krf*w_1_4;
f(16) = kf*gate1*fuel1-krf*w_1_5;
f(17) = kf*sig1*sig1_gate1-krf*w_1_6;
f(18) = kf*in1_tri1*fuel1-krf*w_1_7;
f(19) = ks*in1_tri1*n_tri1-ks*w_1_8*sig2-kf*w_1_8*fuel2+krf*w_2_7- ks*w_1_8*n_tri2+ks*w_2_8*sig3;


f(20) = ks*in1_tri1*n_tri1-ks*w_1_8*sig2-kf*sig2*trans2- ks*sig2*gate2+ks*n_tri2*sig2_gate2+ks*sig2_gate2*fuel2-ks*sig2*w_2_1- kf*sig2*sig2_gate2+krf*w_2_6;
f(21) = -kf*sig2*trans2;
f(22) = kf*sig2*trans2;
f(23) = kf*sig2*trans2-v11+v12-v13;
f(24) = -ks*sig2*gate2+ks*n_tri2*sig2_gate2- kf*gate2*n_tri2+krf*w_2_2-kf*gate2*fuel2+krf*w_2_5;
f(25) = ks*sig2*gate2-ks*n_tri2*sig2_gate2-kf*gate2*n_tri2+krf*w_2_2- kf*n_tri2*w_2_1+krf*w_2_4-ks*w_1_8*n_tri2+ks*w_2_8*sig3;
f(26) = ks*sig2*gate2-ks*n_tri2*sig2_gate2- ks*sig2_gate2*fuel2+ks*sig2*w_2_1-kf*sig2*sig2_gate2+krf*w_2_6;
f(27) = -ks*sig2_gate2*fuel2+ks*sig2*w_2_1-kf*fuel2*w_2_1+krf*w_2_3-kf*gate2*fuel2+krf*w_2_5- kf*w_1_8*fuel2+krf*w_2_7;
f(28) = -ks*sig2*w_2_1+ks*sig2_gate2*fuel2- kf*fuel2*w_2_1+krf*w_2_3-kf*n_tri2*w_2_1+krf*w_2_4;
f(29) = kf*gate2*n_tri2-krf*w_2_2;
f(30) = kf*fuel2*w_2_1-krf*w_2_3;
f(31) = kf*n_tri2*w_2_1-krf*w_2_4;
f(32) = kf*gate2*fuel2-krf*w_2_5;
f(33) = kf*sig2*sig2_gate2-krf*w_2_6;
f(34) = kf*w_1_8*fuel2-krf*w_2_7;
f(35) = ks*w_1_8*n_tri2-ks*w_2_8*sig3-kf*w_2_8*fuel3+krf*w_3_7;


f(36)  = ks*w_1_8*n_tri2-ks*w_2_8*sig3-kf*sig3*trans3-ks*sig3*gate3+ks*n_tri3*sig3_gate3+ks*sig3_gate3*fuel3-ks*sig3*w_3_1- kf*sig3*sig3_gate3+krf*w_3_6;
f(37) = -kf*sig3*trans3;
f(38) = kf*sig3*trans3;
f(39) = kf*sig3*trans3-v21+v22-v23;
f(40) = -ks*sig3*gate3+ks*n_tri3*sig3_gate3- kf*gate3*n_tri3+krf*w_3_2-kf*gate3*fuel3+krf*w_3_5;
f(41) = ks*sig3*gate3-ks*n_tri3*sig3_gate3-kf*gate3*n_tri3+krf*w_3_2- kf*n_tri3*w_3_1+krf*w_3_4;
f(42) = ks*sig3*gate3-ks*n_tri3*sig3_gate3- ks*sig3_gate3*fuel3+ks*sig3*w_3_1-kf*sig3*sig3_gate3+krf*w_3_6;
f(43) = -ks*sig3_gate3*fuel3+ks*sig3*w_3_1- kf*fuel3*w_3_1+krf*w_3_3-kf*gate3*fuel3+krf*w_3_5- kf*w_2_8*fuel3+krf*w_3_7;
f(44) = -ks*sig3*w_3_1+ks*sig3_gate3*fuel3- kf*fuel3*w_3_1+krf*w_3_3-kf*n_tri3*w_3_1+krf*w_3_4;
f(45) = kf*gate3*n_tri3-krf*w_3_2;
f(46) = kf*fuel3*w_3_1-krf*w_3_3;
f(47) = kf*n_tri3*w_3_1-krf*w_3_4;
f(48) = kf*gate3*fuel3-krf*w_3_5;
f(49) = kf*sig3*sig3_gate3-krf*w_3_6;
f(50) = kf*w_2_8*fuel3-krf*w_3_7;
f(51) = ks*w_2_8*n_tri3-ks*w_3_8*sig4-kf*w_3_8*fuel4+krf*w_4_7;


f(52) = ks*w_2_8*n_tri3-ks*w_3_8*sig4-kf*sig4*trans4-ks*sig4*gate4+ks*n_tri4*sig4_gate4+ks*sig4_gate4*fuel4-ks*sig4*w_4_1- kf*sig4*sig4_gate4+krf*w_4_6;
f(53) = -kf*sig4*trans4;
f(54) = kf*sig4*trans4;
f(55) = kf*sig4*trans4-v31 +v32 -v33;
f(56) = -ks*sig4*gate4+ks*n_tri4*sig4_gate4- kf*gate4*n_tri4+krf*w_4_2-kf*gate4*fuel4+krf*w_4_5;
f(57) = ks*sig4*gate4-ks*n_tri4*sig4_gate4-kf*gate4*n_tri4+krf*w_4_2- kf*n_tri4*w_4_1+krf*w_4_4;
f(58) = ks*sig4*gate4-ks*n_tri4*sig4_gate4- ks*sig4_gate4*fuel4+ks*sig4*w_4_1-kf*sig4*sig4_gate4+krf*w_4_6;
f(59) = -ks*sig4_gate4*fuel4+ks*sig4*w_4_1- kf*fuel4*w_4_1+krf*w_4_3-kf*gate4*fuel4+krf*w_4_5- kf*w_3_8*fuel4+krf*w_4_7;
f(60) = -ks*sig4*w_4_1+ks*sig4_gate4*fuel4- kf*fuel4*w_4_1+krf*w_4_3-kf*n_tri4*w_4_1+krf*w_4_4;
f(61) = kf*gate4*n_tri4-krf*w_4_2;
f(62) = kf*fuel4*w_4_1-krf*w_4_3;
f(63) = kf*n_tri4*w_4_1-krf*w_4_4;
f(64) = kf*gate4*fuel4-krf*w_4_5;
f(65) = kf*sig4*sig4_gate4-krf*w_4_6;
f(66) = kf*w_3_8*fuel4-krf*w_4_7;
f(67) = ks*w_3_8*n_tri4-ks*w_4_8*sig5-kf*w_4_8*fuel5+krf*w_5_7- ks*w_4_8*n_tri5+ks*w_5_8*sig6;


f(68) = ks*w_3_8*n_tri4-ks*w_4_8*sig5-kf*sig5*trans5- ks*sig5*gate5+ks*n_tri5*sig5_gate5+ks*sig5_gate5*fuel5-ks*sig5*w_5_1- kf*sig5*sig5_gate5+krf*w_5_6;
f(69) = -kf*sig5*trans5;
f(70) = kf*sig5*trans5;
f(71) = kf*sig5*trans5-v41+v42-v43;
f(72) = -ks*sig5*gate5+ks*n_tri5*sig5_gate5- kf*gate5*n_tri5+krf*w_5_2-kf*gate5*fuel5+krf*w_5_5;
f(73) = ks*sig5*gate5-ks*n_tri5*sig5_gate5-kf*gate5*n_tri5+krf*w_5_2- kf*n_tri5*w_5_1+krf*w_5_4-ks*w_4_8*n_tri5+ks*w_5_8*sig6;
f(74) = ks*sig5*gate5-ks*n_tri5*sig5_gate5- ks*sig5_gate5*fuel5+ks*sig5*w_5_1-kf*sig5*sig5_gate5+krf*w_5_6;
f(75) = -ks*sig5_gate5*fuel5+ks*sig5*w_5_1-kf*fuel5*w_5_1+krf*w_5_3-kf*gate5*fuel5+krf*w_5_5- kf*w_4_8*fuel5+krf*w_5_7;
f(76) = -ks*sig5*w_5_1+ks*sig5_gate5*fuel5- kf*fuel5*w_5_1+krf*w_5_3-kf*n_tri5*w_5_1+krf*w_5_4;
f(77) = kf*gate5*n_tri5-krf*w_5_2;
f(78) = kf*fuel5*w_5_1-krf*w_5_3;
f(79) = kf*n_tri5*w_5_1-krf*w_5_4;
f(80) = kf*gate5*fuel5-krf*w_5_5;
f(81) = kf*sig5*sig5_gate5-krf*w_5_6;
f(82) = kf*w_4_8*fuel5-krf*w_5_7;
f(83) = ks*w_4_8*n_tri5-ks*w_5_8*sig6-kf*w_5_8*fuel6+krf*w_6_7- ks*w_5_8*n_tri6+ks*w_6_8*sig7;


f(84) = ks*w_4_8*n_tri5-ks*w_5_8*sig6-kf*sig6*trans6- ks*sig6*gate6+ks*n_tri6*sig6_gate6+ks*sig6_gate6*fuel6-ks*sig6*w_6_1- kf*sig6*sig6_gate6+krf*w_6_6;
f(85) = -kf*sig6*trans6;
f(86) = kf*sig6*trans6;
f(87) = kf*sig6*trans6-v51+v52-v53;
f(88) = -ks*sig6*gate6+ks*n_tri6*sig6_gate6- kf*gate6*n_tri6+krf*w_6_2-kf*gate6*fuel6+krf*w_6_5;
f(89) = ks*sig6*gate6-ks*n_tri6*sig6_gate6-kf*gate6*n_tri6+krf*w_6_2- kf*n_tri6*w_6_1+krf*w_6_4-ks*w_5_8*n_tri6+ks*w_6_8*sig7;
f(90) = ks*sig6*gate6-ks*n_tri6*sig6_gate6- ks*sig6_gate6*fuel6+ks*sig6*w_6_1-kf*sig6*sig6_gate6+krf*w_6_6;
f(91) = -ks*sig6_gate6*fuel6+ks*sig6*w_6_1-kf*fuel6*w_6_1+krf*w_6_3-kf*gate6*fuel6+krf*w_6_5- kf*w_5_8*fuel6+krf*w_6_7;
f(92) = -ks*sig6*w_6_1+ks*sig6_gate6*fuel6- kf*fuel6*w_6_1+krf*w_6_3-kf*n_tri6*w_6_1+krf*w_6_4;
f(93) = kf*gate6*n_tri6-krf*w_6_2;
f(94) = kf*fuel6*w_6_1-krf*w_6_3;
f(95) = kf*n_tri6*w_6_1-krf*w_6_4;
f(96) = kf*gate6*fuel6-krf*w_6_5;
f(97) = kf*sig6*sig6_gate6-krf*w_6_6;
f(98) = kf*w_5_8*fuel6-krf*w_6_7;
f(99) = ks*w_5_8*n_tri6-ks*w_6_8*sig7-kf*w_6_8*fuel7+krf*w_7_7;


f(100) = ks*w_5_8*n_tri6-ks*w_6_8*sig7-kf*sig7*trans7- ks*sig7*gate7+ks*n_tri7*sig7_gate7+ks*sig7_gate7*fuel7-ks*sig7*w_7_1- kf*sig7*sig7_gate7+krf*w_7_6;
f(101) = -kf*sig7*trans7;
f(102) = kf*sig7*trans7;
f(103) = kf*sig7*trans7-v61+v62-v63;
f(104) = -ks*sig7*gate7+ks*n_tri7*sig7_gate7- kf*gate7*n_tri7+krf*w_7_2-kf*gate7*fuel7+krf*w_7_5;
f(105) = ks*sig7*gate7-ks*n_tri7*sig7_gate7-kf*gate7*n_tri7+krf*w_7_2- kf*n_tri7*w_7_1+krf*w_7_4;
f(106) = ks*sig7*gate7-ks*n_tri7*sig7_gate7- ks*sig7_gate7*fuel7+ks*sig7*w_7_1-kf*sig7*sig7_gate7+krf*w_7_6;
f(107) = -ks*sig7_gate7*fuel7+ks*sig7*w_7_1-kf*fuel7*w_7_1+krf*w_7_3-kf*gate7*fuel7+krf*w_7_5- kf*w_6_8*fuel7+krf*w_7_7;
f(108) = -ks*sig7*w_7_1+ks*sig7_gate7*fuel7- kf*fuel7*w_7_1+krf*w_7_3-kf*n_tri7*w_7_1+krf*w_7_4;
f(109) = kf*gate7*n_tri7-krf*w_7_2;
f(110) = kf*fuel7*w_7_1-krf*w_7_3;
f(111) = kf*n_tri7*w_7_1-krf*w_7_4;
f(112) = kf*gate7*fuel7-krf*w_7_5;
f(113) = kf*sig7*sig7_gate7-krf*w_7_6;
f(114) = kf*w_6_8*fuel7-krf*w_7_7;


f(115) = -v78 +v79 -v80;


% NOTgate1

f(116) = v1-v4-v8+v9-v10;
f(117) = -v2;
f(118) = v1 - v2;
f(119) = -v1;
f(120) = v2;
f(121) = -v3;

f(122) = -v4-v5-v6-v7;
f(123) =  -v5;
f(124) = v5+v7;
f(125) = v5-v83+v84-v85;
f(126) = -v6;
f(127) = -v7;
f(128) = v7;

f(129) = v8-v91+v92-v93;
f(130) = -v9;
f(131) = v8- v9;
f(132) = -v8;
f(133) = v9;
f(134) = -v10;


% NOTgate2

f(135) = v11-v14-v18+v19-v20;
f(136) = -v12;
f(137) = v11 - v12;
f(138) = -v11;
f(139) = v12;
f(140) = -v13;

f(141) = -v14-v15-v16-v17;
f(142) =  -v15;
f(143) = v15+v17;
f(144) = v15-v96+v97-v98;
f(145) = -v16;
f(146) = -v17;
f(147) = v17;

f(148) = v18-v104+v105-v106;
f(149) = -v19;
f(150) = v18 - v19;
f(151) = -v18;
f(152) = v19;
f(153) = -v20;


% NOTgate3

f(154) = v21-v24-v28+v29-v30;
f(155) = -v22;
f(156) = v21 - v22;
f(157) = -v21;
f(158) = v22;
f(159) = -v23;

f(160) = -v24-v25-v26-v27;
f(161) =  -v25;
f(162) = v25+v27;
f(163) = v25-v109+v110-v111;
f(164) = -v26;
f(165) = -v27;
f(166) = v27;

f(167) = v28-v117+v118-v119;
f(168) = -v29;
f(169) = v28 - v29;
f(170) = -v28;
f(171) = v29;
f(172) = -v30;


% NOTgate4

f(173) = v31-v34-v38+v39-v40;
f(174) = -v32;
f(175) = v31 - v32;
f(176) = -v31;
f(177) = v32;
f(178) = -v33;

f(179) = -v34-v35-v36-v37;
f(180) =  -v35;
f(181) = v35+v37;
f(182) = v35-v122+v123-v124;
f(183) = -v36;
f(184) = -v37;
f(185) = v37;

f(186) = v38-v130+v131-v132;
f(187) = -v39;
f(188) = v38 - v39;
f(189) = -v38;
f(190) = v39;
f(191) = -v40;


% NOTgate5

f(192) = v41-v44-v48+v49-v50;
f(193) = -v42;
f(194) = v41 - v42;
f(195) = -v41;
f(196) = v42;
f(197) = -v43;

f(198) = -v44-v45-v46-v47;
f(199) = -v45;
f(200) = v45+v47;
f(201) = v45-v135+v136-v137;
f(202) = -v46;
f(203) = -v47;
f(204) = v47;

f(205) = v48-v143+v144-v145;
f(206) = -v49;
f(207) = v48 - v49;
f(208) = -v48;
f(209) = v49;
f(210) = -v50;


% NOTgate6

f(211) = v51-v54-v58+v59-v60;
f(212) = -v52;
f(213) = v51 - v52;
f(214) = -v51;
f(215) = v52;
f(216) = -v53;

f(217) = -v54-v55-v56-v57;
f(218) =  -v55;
f(219) = v55+v57;
f(220) = v55-v148+v149-v150;
f(221) = -v56;
f(222) = -v57;
f(223) = v57;

f(224) = v58-v156+v157-v158;
f(225) = -v59;
f(226) = v58 - v59;
f(227) = -v58;
f(228) = v59;
f(229) = -v60;


% NOTgate7

f(230) = v61-v64-v68+v69-v70;
f(231) = -v62;
f(232) = v61 - v62;
f(233) = -v61;
f(234) = v62;
f(235) = -v63;

f(236) = -v64-v65-v66-v67;
f(237) =  -v65;
f(238) = v65+v67;
f(239) = v65-v161+v162-v163;
f(240) = -v66;
f(241) = -v67;
f(242) = v67;

f(243) = v68-v169+v170-v171;
f(244) = -v69;
f(245) = v68 - v69;
f(246) = -v68;
f(247) = v69;
f(248) = -v70;


% NOTgate8

f(249) = v71-v74;
f(250) = -v72;
f(251) = v71 - v72;
f(252) = -v71;
f(253) = v72;
f(254) = -v73;

f(255) = -v74-v75-v76-v77;
f(256) =  -v75;
f(257) = v75+v77;
f(258) = v75-v174+v175-v176;
f(259) = -v76;
f(260) = -v77;
f(261) = v77;


% ANDgate1

f(262) = v78 -v81 -v89 +v90;
f(263) = -v79 -v82 -v87;
f(264) = v78 - v79;
f(265) = -v78;
f(266) = +v79;
f(267) = -v80;
f(268) = -v81;
f(269) = -v82;

f(270) = v83 -v86 -v88;
f(271) = -v84;
f(272) = v83 - v84;
f(273) = -v83;
f(274) = v84;
f(275) = -v85;
f(276) = -v86;

f(277) = v87+v88;
f(278) = v87;
f(279) = v88;
f(280) = -v87 -v88;

f(281) = v89-v182 -v183 -v184 +v185 -v186;  
f(282) = -v90;
f(283) = v89 -v90;
f(284) = -v89;
f(285) = v90;

%ANDgate2

f(286) = v91 -v94 -v102 +v103;
f(287) = -v92 -v95 -v100;
f(288) = v91 - v92;
f(289) = -v91;
f(290) = v92;
f(291) = -v93;
f(292) = -v94;
f(293) = -v95;


f(294) = v96 -v99 -v101;
f(295) = -v97;
f(296) = v96 - v97;
f(297) = -v96;
f(298) = v97;
f(299) = -v98;
f(300) = -v99;

f(301) = v100 +v101;
f(302) = v100;
f(303) = v101;
f(304) = -v100 -v101;

f(305) = v102-v187 -v188 +v189 -v190;
f(306) = -v103;
f(307) = v102 -v103;
f(308) = -v102;
f(309) = v103;


% ANDgate3


f(310) = v104 -v107 -v115 +v116;
f(311) = -v105 -v108 -v113;
f(312) = v104 - v105;
f(313) = -v104;
f(314) = +v105;
f(315) = -v106;
f(316) = -v107;
f(317) = -v108;

f(318) = v109 -v112 -v114;
f(319) = -v110;
f(320) = v109 - v110;
f(321) = -v109;
f(322) = v110;
f(323) = -v111;
f(324) = -v112;

f(325) = v113+v114;
f(326) = v113;
f(327) = v114;
f(328) = -v113 -v114;

f(329) = v115-v191 -v192 +v193 -v194;
f(330) = -v116;
f(331) = v115 -v116;
f(332) = -v115;
f(333) = v116;

%ANDgate4


f(334) = v117 -v120 -v128 +v129;
f(335) = -v118 -v121 -v126;
f(336) = v117 - v118;
f(337) = -v117;
f(338) = +v118;
f(339) = -v119;
f(340) = -v120;
f(341) = -v121;


f(342) = v122 -v125 -v127;
f(343) = -v123;
f(344) = v122 - v123;
f(345) = -v122;
f(346) = v123;
f(347) = -v124;
f(348) = -v125;

f(349) = v126 +v127;
f(350) = v126;
f(351) = v127;
f(352) = -v126 -v127;


f(353) = v128-v195 +v196 -v197;
f(354) = -v129;
f(355) = v128 -v129;
f(356) = -v128;
f(357) = v129;


% ANDgate5


f(358) = v130 -v133 -v141 +v142;
f(359) = -v131 -v134 -v139;
f(360) = v130 - v131;
f(361) = -v130;
f(362) = +v131;
f(363) = -v132;
f(364) = -v133;
f(365) = -v134;

f(366) = v135 -v138 -v140;
f(367) = -v136;
f(368) = v135 - v136;
f(369) = -v135;
f(370) = v136;
f(371) = -v137;
f(372) = -v138;

f(373) = v139+v140;
f(374) = v139;
f(375) = v140;
f(376) = -v139 -v140;

f(377) = v141-v198 -v199 + v200 -v201;
f(378) = -v142;
f(379) = v141 -v142;
f(380) = -v141;
f(381) = v142;


%ANDgate6


f(382) = v143 -v146 -v154 +v155;
f(383) = -v144 -v147 -v152;
f(384) = v143 - v144;
f(385) = -v143;
f(386) = +v144;
f(387) = -v145;
f(388) = -v146;
f(389) = -v147;


f(390) = v148 -v151 -v153;
f(391) = -v149;
f(392) = v148 - v149;
f(393) = -v148;
f(394) = v149;
f(395) = -v150;
f(396) = -v151;

f(397) = v152 +v153;
f(398) = v152;
f(399) = v153;
f(400) = -v152 -v153;

f(401) = v154-v202 +v203 -v204;
f(402) = -v155;
f(403) = v154 -v155;
f(404) = -v154;
f(405) = v155;


% ANDgate7


f(406) = v156 -v159 -v167 +v168;
f(407) = -v157 -v160 -v165;
f(408) = v156 - v157;
f(409) = -v156;
f(410) = +v157;
f(411) = -v158;
f(412) = -v159;
f(413) = -v160;

f(414) = v161 -v164 -v166;
f(415) = -v162;
f(416) = v161 - v162;
f(417) = -v161;
f(418) = v162;
f(419) = -v163;
f(420) = -v164;

f(421) = v165+v166;
f(422) = v165;
f(423) = v166;
f(424) = -v165 -v166;

f(425) = v167-v205 +v206 -v207;
f(426) = -v168;
f(427) = v167 -v168;
f(428) = -v167;
f(429) = v168;


%ANDgate8


f(430) = v169 -v172 -v180 +v181;
f(431) = -v170 -v173 -v178;
f(432) = v169 - v170;
f(433) = -v169;
f(434) = +v170;
f(435) = -v171;
f(436) = -v172;
f(437) = -v173;


f(438) = v174 -v177 -v179;
f(439) = -v175;
f(440) = v174 - v175;
f(441) = -v174;
f(442) = v175;
f(443) = -v176;
f(444) = -v177;

f(445) = v178 +v179;
f(446) = v178;
f(447) = v179;
f(448) = -v178 -v179;


f(449) = v180;
f(450) = -v181;
f(451) = v180 -v181;
f(452) = -v180;
f(453) = v181;



f(454) = v182 +v187 +v191 +v195;
f(455) = v183 +v188 +v198 +v202;
f(456) = v184 +v192 +v199 +v205;

f(457) = -v185 -v189 -v193 -v196 -v200 -v203 -v206;

f(458) = v182 + v183 +v184 -v185;
f(459) = v187 +v188 -v189;
f(460) = v191 +v192 -v193;
f(461) = v195 -v196;
f(462) = v198 +v199 -v200;
f(463) = v202 -v203;
f(464) = v205-v206;

f(465) = -v182 -v187 -v191 -v195;
f(466) = -v183 -v188 -v198 -v202;
f(467) = -v184 -v192 -v199 -v205;
f(468) =  v185 +v189 +v193 +v196 +v200 +v203 +v206;
f(469) = -v186;
f(470) = -v190;
f(471) = -v194;
f(472) = -v197;
f(473) = -v201;
f(474) = -v204;
f(475) = -v207;

f(476) = -v71 + v72 - v73;
end

